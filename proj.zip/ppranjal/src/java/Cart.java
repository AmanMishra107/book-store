import java.util.HashMap;
import java.util.Map;

public class Cart {
    private Map<String, Integer> items;

    public Cart() {
        items = new HashMap<>();
    }

    public void addItem(String product, int price) {
        if (items.containsKey(product)) {
            // If the product already exists in the cart, update its quantity
            int quantity = items.get(product);
            items.put(product, quantity + 1);
        } else {
            // Otherwise, add the product to the cart with quantity 1
            items.put(product, 1);
        }
    }

    public Map<String, Integer> getItems() {
        return items;
    }
}

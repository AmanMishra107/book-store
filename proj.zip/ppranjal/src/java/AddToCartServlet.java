import java.io.IOException;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve product and quantity parameters from the request
        String product = request.getParameter("product");
        int price = Integer.parseInt(request.getParameter("price"));

        // Perform any necessary validation on the product and quantity parameters
        
        // Add the product to the cart
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        // Add the product to the cart
        cart.addItem(product, price);

        // Convert cart items to a string in a format easily processed in JSP
        StringBuilder cartItemsString = new StringBuilder();
        for (Map.Entry<String, Integer> entry : cart.getItems().entrySet()) {
            cartItemsString.append(entry.getKey()).append(": ").append(entry.getValue()).append("<br>");
        }

        // Set cart items as an attribute in request
        request.setAttribute("cartItems", cartItemsString.toString());

        // Forward the request to the JSP page
        request.getRequestDispatcher("cart.jsp").forward(request, response);
    }
}
